/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankingapp;
import java.util.Scanner;
public class BankingApp {
    
    private double balance;
    private String accountHolder;
    
    public BankingApp(String accountHolder , double initialBalance){
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
    }
    
    public void deposit(double amount){
        if(amount > 0){
            balance += amount;
            System.out.println("Deposit successful. Current balance: $ " + balance);
        }
    }
    
    public void withdraw(double amount){
        if (amount > 0 && amount <= balance){
            balance -= amount;
            System.out.println("withdrawl successful. Current balance: $ " + balance);
        }
    }
    
    public void checkBalance(){
        System.out.println("Current balance: $" + balance);
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter account holder's name: ");
        String accountHolder = sc.next();
        System.out.print("Enter iniial balance: ");
        double initialBalance = sc.nextDouble();
        
        BankingApp account = new BankingApp(accountHolder , initialBalance);
        
        boolean exit = false;
        while(!exit){
            System.out.println("\nWelcome, "+ account.accountHolder + "! please choose an option: ");
            System.out.println("1. Deposit: ");
            System.out.println("2. Withdraw: ");
            System.out.println("3. Check Balance: ");
            System.out.println("4. Exit");
            System.out.println("\nEnter your choice: ");
        
            int choice = sc.nextInt();
                                                                            
        switch (choice){
            case 1 :
                System.out.print("Enter deposit amount: ");
                double depositAmount = sc.nextDouble();
                account.deposit(depositAmount);
                break;
            case 2 :
                System.out.print("Enter withdraw amount: ");
                double withdrawalAmount = sc.nextDouble();
                account.withdraw(withdrawalAmount);
                break;
            case 3 :
                account.checkBalance();
                break;
            case 4 :
                exit = true;
                System.out.println("Thank you for using our banking application");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
        }
        sc.close();
    }
    
}
